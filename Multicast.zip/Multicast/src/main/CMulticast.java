package main;
import java.net.*;
import java.io.*;

public class CMulticast {
    public static void main(String[] args) {
        InetAddress gpo=null;
        
        try{
            MulticastSocket c1=new MulticastSocket(9999);
            c1.setReuseAddress(true);
            c1.setTimeToLive(1);
            String msj1= "hola cliente";
            byte[] b =msj1.getBytes();
            try{
                gpo=InetAddress.getByName("228.1.1.1");
            }catch(UnknownHostException u){
                System.out.println("Dirección no válida");
            }
            c1.joinGroup(gpo);
            System.out.println("Unido al grupo");
            for(;;){
                DatagramPacket p=new DatagramPacket(new byte[10],10);
                c1.receive(p);
                String msj=new String(p.getData());
                System.out.println("Datagrama recibido..."+msj);
                System.out.println("Servidor descubierto: "+p.getAddress()+"Puerto: "+p.getPort());
                
                DatagramPacket r= new DatagramPacket(b,b.length,gpo,9998);
                c1.send(r);
                System.out.println("Enviando mensaje: "+msj1+" con un TTL= "+c1.getTimeToLive());
                try{
                    Thread.sleep(3000);
                }
                catch(InterruptedException ie){
                    ie.printStackTrace();
                }
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
