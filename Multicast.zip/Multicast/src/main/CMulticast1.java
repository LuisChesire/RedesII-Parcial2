package main;
import java.net.*;
import java.io.*;

public class CMulticast1 {
    public static void main(String[] args) {
        InetAddress gpo=null;
        try{
            MulticastSocket c1=new MulticastSocket(9998);
            c1.setReuseAddress(true);
            try{
                gpo=InetAddress.getByName("228.1.1.1");
            }catch(UnknownHostException u){
                System.out.println("Dirección no válida");
            }
            c1.joinGroup(gpo);
            System.out.println("Unido al grupo");
            for(;;){
                DatagramPacket q=new DatagramPacket(new byte[10],10);
                c1.receive(q);
                String msj=new String(q.getData());
                System.out.println("Datagrama recibido..."+msj);
                System.out.println("Servidor descubierto: "+q.getAddress()+"Puerto: "+q.getPort());
                
                 DatagramPacket r=new DatagramPacket(new byte[10],10);
                c1.receive(r);
                String msj1=new String(r.getData());
                System.out.println("Datagrama recibido..."+msj);
                System.out.println("Servidor descubierto: "+r.getAddress()+"Puerto: "+r.getPort());
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
