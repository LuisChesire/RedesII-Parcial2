import java.nio.channels.*;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Iterator;

public class ServidorNB {
    public static void main(String[] args){
        try{
            String EECO="";
            int ports[] = new int[]{9000, 9001};
            
            Selector sel = Selector.open();
            
            for (int port : ports) {
                ServerSocketChannel serverChannel = ServerSocketChannel.open();
                serverChannel.configureBlocking(false);
                serverChannel.socket().bind(new InetSocketAddress(port));
                serverChannel.register(sel, SelectionKey.OP_ACCEPT);
                System.out.println("Puerto: " + port);
            }
         
            System.out.println("Esperando clientes...");
            
            //Este while no se para que sea(Para escuchar conexiones)..
            while(true){
                sel.select();
                //Carece de constructor
                Iterator<SelectionKey>it = sel.selectedKeys().iterator();
                while(it.hasNext()){
                    SelectionKey k = (SelectionKey)it.next();
                    it.remove();
                    //Si es aceptación
                    if(k.isAcceptable()){
                        SocketChannel cl = ((ServerSocketChannel)k.channel()).accept();
                        System.out.println("Cliente conectado desde "+cl.socket().getInetAddress()+":"+cl.socket().getPort());
                        cl.configureBlocking(false);
                        cl.register(sel,SelectionKey.OP_READ|SelectionKey.OP_WRITE);
                        switch(cl.socket().getPort()) {
                            case 9000:
                                System.out.println("Desde puerto: " + cl.socket().getPort());
                                continue;
                            case 9001:
                                 System.out.println("Desde puerto: " + cl.socket().getPort());
                                continue;
                        }
                    }//if
                    //Si es de escritura
                    if(k.isReadable()){
                        try{
                        SocketChannel ch = (SocketChannel)k.channel();
                        //Son los byes que asociamos
                        ByteBuffer b = ByteBuffer.allocate(2000);
                        //Limpiamos el buffer
                        b.clear();
                        int n = 0; 
                        String msj="";
                        //Leemos del buffer, mediante el canal
                        // Los bytes se almacenan en 'n'
                        n = ch.read(b);
                        //Voltea el buffer de escritura a lectura
                        b.flip();
                        //Si está leyendo los bytes, entonces
                            if(n>0)
                               msj = new String(b.array(),0,n);
                            System.out.println("Mensaje  de "+n+" bytes recibido: "+msj);
                            if (msj.equalsIgnoreCase("SALIR")){
                                k.interestOps(SelectionKey.OP_WRITE);
                                ch.close();
                               // k.cancel();
                            }else{
                                EECO="ECO->"+msj;
                                k.interestOps(SelectionKey.OP_WRITE);
                            }//else

                        }catch(IOException io){}
                        continue;
                    //Si es acceptable
                    }else if(k.isWritable()){
                           try{
                           SocketChannel ch = (SocketChannel)k.channel();
                           ByteBuffer bb = ByteBuffer.wrap(EECO.getBytes());
                           ch.write(bb);
                           System.out.println("Mensaje de "+EECO.length()+" bytes enviado: "+EECO);
                           EECO="";
                           }catch(IOException io){}
                            k.interestOps(SelectionKey.OP_READ);
                           continue;
                    }//if
                }//while
                
            }//while
        }catch(Exception e){
            e.printStackTrace();
        }//catch
              
        
    }//main
}
